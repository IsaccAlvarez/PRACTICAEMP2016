$(document).ready(function(){
listAsesor();
});
//funcionalidad de guardar
$("#guardar").click(function(){
  var nombre = $("#nomb").val();
  var inic = $("#ini").val();
  var telef = $("#telef").val();
  var ePersonal = $("#correoP").val();
  var eEmpresa = $("#correoE").val();
  var estd = $("#estado").val();
  var fecIngre = $("#fechaI").val();
  var fcreac = $("#fCreacion").val();
  var fUltMod = $("#fum").val();
  var iAsUltMod = $("#iaum").val();

  var route = "/asesor";

  var token = $("#token").val();

   $.ajax({
         url: route,
         headers: {'X-CSRF-TOKEN': token},
         type: 'POST',
         dataType: 'json',
         data:{nombre: nombre,
              iniciales: inic,
              telefono: telef,
              emailPersonal: ePersonal,
              emailEmpresa: eEmpresa,
              estado: estd,
              fechaIngreso: fecIngre,
              idAsesorUltimaModificacion: iAsUltMod},

        success:function(){
           listAsesor();
           $("#myModalCreate").modal('toggle');
           $("#msj-success").fadeIn();
        },
        error:function(msj){
          $("#msj-error").fadeIn();
        }
   });
});
//funcionalidad cancelar
$("#cancelar").click(function() {
   window.location='http://localhost:8000/asesor';
});
//funcionalidad de la paginacion
 $(document).on("click",".pagination li a",function(e){
   e.preventDefault();
   var url = $(this).attr("href");
       $.ajax({
           type:'get',
           url:url,
           success: function(data){
               $('#lista').empty().html(data);
           }
       });
 });
 //---------------------------------------------------------------
 //listar los registros guardados
var listAsesor = function() {
  $.ajax({
    type:'get',
    url:'/listall',
    success: function(data){
      $("#lista").empty().html(data);
    }
  });
}

//----------------------------------------------------------------
//mostrar el model con el form y los datos
var Mostrar = function(idAsesor)
{
  var route = "http://localhost:8000/asesor/"+idAsesor+"/edit";
  $.get(route, function(data){
    console.log(data.idAsesor);
    $("#idAsesor").val(data.idAsesor);
    $("#nomb").val(data.nombre);
    $("#ini").val(data.iniciales);
    $("#telef").val(data.telefono);
    $("#correoP").val(data.emailPersonal);
    $("#correoE").val(data.emailEmpresa);
    $("#estado").val(data.estado);
    $("#fechaI").val(data.fechaIngreso);

  });
}
//actualizar registros
$("#actualizar").click(function() {
  var id = $("#idAsesor").val();
  var nombre = $("#nomb").val();
  var inic = $("#ini").val();
  var telef = $("#telef").val();
  var ePersonal = $("#correoP").val();
  var eEmpresa = $("#correoE").val();
  var estd = $("#estado").val();
  var fecIngre = $("#fechaI").val();
  var iAsUltMod = $("#iaum").val();

  var route = "/asesor/"+id+"";
  console.log(route);
  var token = $("#token").val();

 $.ajax({
   url: route,
   headers: {'X-CSRF-TOKEN': token},
   type : 'PUT',
   dataType: 'json',
   data:{nombre: nombre,
        iniciales: inic,
        telefono: telef,
        emailPersonal: ePersonal,
        emailEmpresa: eEmpresa,
        estado: estd,
        fechaIngreso: fecIngre,
        idAsesorUltimaModificacion: iAsUltMod},
     success: function(data){
        if (data.success == 'true')
         {
            listAsesor();
            $("#myModal").modal('toggle');
            $("#message-update").fadeIn();
        }
    }

 });

});

//CUANDO CIERRAS LA VENTANA MODAL
$("#myModal").on("hidden.bs.modal", function () {
    $("#message-error").fadeOut()
});

//-------------------------------------------
//eliminar registros
var Eliminar = function(idAsesor,nombre) {

  $.alertable.confirm("<span style='color:#000'>¿Está seguro de eliminar el Asesor?</span>"+"<strong><span style='color:#ff0000'>"+ nombre+"</span></strong>").then(function() {

      var route = "/asesor/"+idAsesor+"";
      var token = $("#token").val();

      $.ajax({
        url: route,
        headers: {'X-CSRF-TOKEN': token},
        type: 'DELETE',
        dataType: 'json',
        success: function(data){
        if (data.success == 'true')
        {
          listAsesor();
          $("#message-delete").fadeIn();
          $('#message-delete').show().delay(3000).fadeOut(1);
        }
      }
      });


    });

}
